import unittest
from debt_tracker.engine import calculate

BASE = {'principal': 3000000000, 'months': 24, 'annual_rate': 0,
        'business_lines': [{'name': 'A', 'monthly_sales': 1000000000, 'variable_pct': 50}],
        'fixed_cost': 50000000, 'minimum_cash': 0}

class DebtTests(unittest.TestCase):
    def test_zero_interest_target(self):
        r = calculate(BASE)
        self.assertTrue(r['target_met'])
        self.assertEqual(r['paid_off_month'], 7)
        self.assertEqual(r['rows'][0]['interest'], 0)

    def test_no_cash_cannot_pay(self):
        r = calculate({**BASE, 'business_lines': [{'monthly_sales': 0, 'variable_pct': 0}]})
        self.assertFalse(r['target_met'])
        self.assertEqual(r['ending_debt'], 3000000000)

    def test_interest(self):
        r = calculate({**BASE, 'annual_rate': 12})
        self.assertEqual(r['rows'][0]['interest'], 30000000)
        self.assertGreater(r['total_interest'], 0)

    def test_dividend_does_not_change_fcff(self):
        a = calculate(BASE)
        b = calculate({**BASE, 'investor_distribution': 10000000})
        self.assertEqual(a['rows'][0]['fcff_before_debt'], b['rows'][0]['fcff_before_debt'])
        self.assertEqual(b['rows'][0]['dividend_shortfall'], 10000000)
        self.assertEqual(b['rows'][0]['investor_distribution'], 0)

    def test_investor_first_reduces_debt_payment(self):
        r = calculate({**BASE, 'distribution_priority': 'before_debt', 'investor_distribution': 10000000})
        self.assertEqual(r['rows'][0]['investor_distribution'], 10000000)
        self.assertEqual(r['rows'][0]['paid'], 440000000)

    def test_cash_collection_lag(self):
        r = calculate({**BASE, 'collection_pct': 20})
        self.assertEqual(r['rows'][0]['receipts'], 200000000)
        self.assertEqual(r['rows'][1]['receipts'], 1000000000)
        self.assertEqual(r['rows'][0]['receivables_end'], 800000000)

    def test_nan_rejected(self):
        with self.assertRaises(ValueError): calculate({**BASE, 'principal': 'NaN'})

    def test_negative_rejected(self):
        with self.assertRaises(ValueError): calculate({**BASE, 'fixed_cost': -1})

    def test_fractional_months_rejected(self):
        with self.assertRaises(ValueError): calculate({**BASE, 'months': 1.8})

    def test_invalid_priority_rejected(self):
        with self.assertRaises(ValueError):
            calculate({**BASE, 'debts': [{'principal': 3000, 'priority': 0}]})

    def test_no_extra_sweep(self):
        r = calculate({**BASE, 'sweep_pct': 0})
        self.assertEqual(r['rows'][0]['paid'], 125000000)

    def test_cash_does_not_go_negative_because_of_dividend(self):
        r = calculate({**BASE, 'opening_cash': 0, 'minimum_cash': 100000000,
                      'business_lines': [{'monthly_sales': 0, 'variable_pct': 0}],
                      'fixed_cost': 0, 'investor_distribution': 100000000})
        self.assertEqual(r['rows'][0]['ending_cash'], 0)
        self.assertEqual(r['rows'][0]['investor_distribution'], 0)

    def test_multi_creditor_balances(self):
        r = calculate({**BASE, 'debts': [
            {'creditor': 'A', 'principal': 100000000, 'annual_rate': 0},
            {'creditor': 'B', 'principal': 200000000, 'annual_rate': 0}]})
        self.assertEqual(r['initial_debt'], 300000000)
        self.assertEqual(r['paid_off_month'], 1)
        self.assertEqual(len(r['rows'][0]['by_creditor']), 2)

    def test_priority_loan_minimum_first(self):
        r = calculate({**BASE, 'debts': [
            {'creditor': 'A', 'principal': 1000000000, 'annual_rate': 0, 'minimum_payment': 200000000, 'priority': 2},
            {'creditor': 'B', 'principal': 1000000000, 'annual_rate': 0, 'minimum_payment': 400000000, 'priority': 1}]})
        self.assertEqual(r['rows'][0]['paid'], 450000000)
        self.assertEqual(r['rows'][0]['by_creditor'][0]['paid'], 50000000)
        self.assertEqual(r['rows'][0]['by_creditor'][1]['paid'], 400000000)
        self.assertEqual(r['rows'][0]['shortfall'], 150000000)

    def test_negative_operating_cash_reports_gap(self):
        r = calculate({**BASE, 'business_lines': [{'monthly_sales': 0, 'variable_pct': 0}]})
        self.assertEqual(r['rows'][0]['cash_funding_gap'], 50000000)

    def test_empty_business_lines_rejected(self):
        with self.assertRaises(ValueError):calculate({**BASE, 'business_lines': []})

if __name__ == '__main__':
    unittest.main()
