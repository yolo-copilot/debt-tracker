"""Localhost-only debt scenario simulator with SQLite persistence and JSON API."""
import argparse,json,sqlite3,os,secrets
from pathlib import Path
from datetime import datetime,timezone
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from .engine import calculate
ROOT=Path(__file__).resolve().parent.parent
HTML=ROOT/'web_debt'/'index.html'

def init(db):
    Path(db).parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(db) as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS scenarios (id INTEGER PRIMARY KEY, name TEXT NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL)')
        conn.execute('CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, action TEXT NOT NULL, scenario_id INTEGER, at TEXT NOT NULL)')

def handler(db,token):
 class Handler(BaseHTTPRequestHandler):
    def _send(self,status,obj):
        body=json.dumps(obj,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
    def do_GET(self):
        if self.path=='/':
            body=HTML.read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'");self.end_headers();self.wfile.write(body);return
        if self.path=='/api/health':return self._send(200,{'status':'ok','application':'YOLO Debt Tracker'})
        if self.path=='/api/scenarios':
            with sqlite3.connect(db) as conn:
                rows=conn.execute('SELECT id,name,updated_at FROM scenarios ORDER BY id DESC LIMIT 100').fetchall()
            return self._send(200,{'scenarios':[dict(zip(['id','name','updated_at'],r)) for r in rows]})
        return self._send(404,{'error':'Tidak ditemukan'})
    def do_POST(self):
        if self.path not in ('/api/simulate','/api/scenarios'):return self._send(404,{'error':'Tidak ditemukan'})
        if token and not secrets.compare_digest(self.headers.get('X-Debt-Token',''),token):return self._send(401,{'error':'Token tidak sesuai'})
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':return self._send(415,{'error':'Gunakan application/json'})
        try:
            length=int(self.headers.get('Content-Length','-1'))
            if not 0<length<=100_000:return self._send(413,{'error':'Ukuran tidak valid'})
            data=json.loads(self.rfile.read(length),parse_constant=lambda x: (_ for _ in ()).throw(ValueError('NaN/Infinity dilarang')))
            p=data.get('model',data) if isinstance(data,dict) else data
            result=calculate(p)
            if self.path=='/api/scenarios':
                name=str(data.get('name','Skenario'))[:100].strip() or 'Skenario'
                with sqlite3.connect(db) as conn:
                    c=conn.execute('INSERT INTO scenarios(name,payload,updated_at) VALUES(?,?,?)',(name,json.dumps(p,ensure_ascii=False),datetime.now(timezone.utc).isoformat()))
                    conn.execute('INSERT INTO audit(action,scenario_id,at) VALUES(?,?,?)',('CREATE',c.lastrowid,datetime.now(timezone.utc).isoformat()))
                    result['scenario_id']=c.lastrowid
            return self._send(200,result)
        except (ValueError,KeyError,TypeError,OverflowError) as e:return self._send(400,{'error':str(e)})
        except Exception:
            return self._send(500,{'error':'Kesalahan internal'})
    def log_message(self,fmt,*args):pass
 return Handler

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--host',default='127.0.0.1');ap.add_argument('--port',type=int,default=8090);ap.add_argument('--db',default='data/debt.db');args=ap.parse_args()
    if args.host not in ('127.0.0.1','localhost','0.0.0.0'):raise ValueError('host tidak diizinkan')
    init(args.db);srv=ThreadingHTTPServer((args.host,args.port),handler(args.db,os.environ.get('DEBT_API_TOKEN','')))
    print(f'YOLO Debt Tracker http://{args.host}:{args.port}',flush=True);srv.serve_forever()
if __name__=='__main__':main()
