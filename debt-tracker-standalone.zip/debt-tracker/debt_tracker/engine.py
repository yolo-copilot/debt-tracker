"""Deterministic monthly debt and cash planning, Decimal-only calculations.

This is a scenario planner, not a lender ledger or a GAAP cash flow statement.
"""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

D = Decimal
CENT = D('0.01')
ZERO = D('0')


def value(x, label, low=ZERO, high=D('1000000000000000')):
    if isinstance(x, bool) or x is None:
        raise ValueError(f'{label}: angka tidak valid')
    try:
        z = D(str(x))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f'{label}: angka tidak valid') from None
    if not z.is_finite() or not D(str(low)) <= z <= D(str(high)):
        raise ValueError(f'{label}: di luar batas')
    return z


def money(x):
    return x.quantize(CENT, rounding=ROUND_HALF_UP)


def amount(x):
    return float(money(x))


def annuity(principal, annual_rate, months):
    rate = annual_rate / D('1200')
    if rate == 0:
        return money(principal / months)
    return money(principal * rate / (1 - (1 + rate) ** (-months)))


def parse_debts(payload, months):
    raw = payload.get('debts')
    if raw is None:
        raw = [{'creditor': 'Kreditur utama', 'principal': payload.get('principal', 3000000000),
                'annual_rate': payload.get('annual_rate', 0)}]
    if not isinstance(raw, list) or not 1 <= len(raw) <= 30:
        raise ValueError('Daftar hutang harus terdiri dari 1–30 kreditur')
    debts = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f'Hutang {i + 1}: format tidak valid')
        principal = money(value(item.get('principal'), f'Pokok hutang {i + 1}', D('0.01')))
        annual = value(item.get('annual_rate', 0), f'Bunga hutang {i + 1}', ZERO, D('100'))
        if item.get('minimum_payment') is None:
            minimum = annuity(principal, annual, months)
        else:
            minimum = money(value(item['minimum_payment'], f'Cicilan minimum hutang {i + 1}'))
        debts.append({'id': str(i + 1), 'creditor': str(item.get('creditor') or f'Kreditur {i + 1}')[:100],
                      'balance': principal, 'opening': principal, 'annual': annual, 'minimum': minimum,
                      'priority': int(value(item.get('priority', i + 1), f'Prioritas {i + 1}', 1, 999))})
    return debts


def calculate(payload):
    if not isinstance(payload, dict):
        raise ValueError('Payload harus berupa objek')
    mval = value(payload.get('months', 24), 'Tenor', 1, 360)
    if mval != mval.to_integral_value():
        raise ValueError('Tenor harus bilangan bulat')
    months = int(mval)
    debts = parse_debts(payload, months)
    initial_debt = sum((d['opening'] for d in debts), ZERO)
    scheduled = sum((d['minimum'] for d in debts), ZERO)
    cash = money(value(payload.get('opening_cash', 0), 'Kas awal'))
    min_cash = value(payload.get('minimum_cash', 0), 'Kas minimum')
    growth = value(payload.get('monthly_growth_pct', 0), 'Pertumbuhan bulanan', -50, 100) / 100
    fixed = value(payload.get('fixed_cost', 0), 'Biaya tetap')
    tax = value(payload.get('tax_cash', 0), 'Pajak kas')
    capex = value(payload.get('capex', 0), 'Belanja modal')
    wc = value(payload.get('working_capital_increase', 0), 'Tambahan modal kerja')
    other = value(payload.get('other_cash_out', 0), 'Belanja masalah/lainnya')
    promised_dividend = money(value(payload.get('investor_distribution', 0), 'Distribusi investor'))
    collection = value(payload.get('collection_pct', 100), 'Persentase penerimaan', 0, 100) / 100
    sweep = value(payload.get('sweep_pct', 100), 'Surplus pelunasan ekstra', 0, 100) / 100
    distribution_priority = payload.get('distribution_priority', 'after_debt')
    if distribution_priority not in ('before_debt', 'after_debt'):
        raise ValueError('Urutan distribusi tidak valid')
    lines = payload.get('business_lines', [])
    if not isinstance(lines, list) or not 1 <= len(lines) <= 30:
        raise ValueError('Diperlukan 1–30 lini usaha')
    businesses = []
    for i, line in enumerate(lines):
        if not isinstance(line, dict):
            raise ValueError('Lini usaha tidak valid')
        sales = value(line.get('monthly_sales', 0), f'Omzet lini {i + 1}')
        variable = value(line.get('variable_pct', 0), f'Biaya variabel lini {i + 1}', 0, 100) / 100
        businesses.append((str(line.get('name', f'Bisnis {i + 1}'))[:100], sales, variable))

    rows = []
    total_interest = ZERO
    total_gap = ZERO
    total_dividend_gap = ZERO
    prior_receivable = ZERO
    first_paid_off = None
    for month in range(1, months + 1):
        factor = (1 + growth) ** (month - 1)
        sales = money(sum((s * factor for _, s, _ in businesses), ZERO))
        variable = money(sum((s * v * factor for _, s, v in businesses), ZERO))
        # One-month collection lag: uncollected sales from month t-1 are received in month t.
        new_receivable = money(sales * (1 - collection))
        receipts = money(sales * collection + prior_receivable)
        prior_receivable = new_receivable
        cash_before_financing = money(receipts - variable - fixed - tax - capex - wc - other)
        available = max(ZERO, money(cash + cash_before_financing - min_cash))

        dividend_paid = ZERO
        if distribution_priority == 'before_debt':
            dividend_paid = min(promised_dividend, available)
            available -= dividend_paid

        details = []
        for d in debts:
            interest = money(d['balance'] * d['annual'] / 1200)
            due = min(d['balance'] + interest, d['minimum']) if d['balance'] else ZERO
            details.append({'debt': d, 'interest': interest, 'due': money(due), 'payment': ZERO})
            total_interest += interest

        # Honor minimums first. If funds are insufficient, honor contractual priority order.
        for line in sorted(details, key=lambda x: (x['debt']['priority'], -x['debt']['annual'])):
            p = min(available, line['due'])
            line['payment'] += p
            available -= p
        # Allocate extra repayments by effective rate (avalanche), except explicit priority override.
        extra_budget = money(available * sweep)
        for line in sorted(details, key=lambda x: (x['debt']['priority'], -x['debt']['annual'])):
            outstanding = max(ZERO, line['debt']['balance'] + line['interest'] - line['payment'])
            p = min(outstanding, extra_budget)
            line['payment'] += p
            extra_budget -= p

        payment = money(sum((x['payment'] for x in details), ZERO))
        due = money(sum((x['due'] for x in details), ZERO))
        interest = money(sum((x['interest'] for x in details), ZERO))
        gap = money(max(ZERO, due - payment))
        total_gap += gap
        for item in details:
            d = item['debt']
            d['balance'] = money(max(ZERO, d['balance'] + item['interest'] - item['payment']))
        ending_debt = money(sum((d['balance'] for d in debts), ZERO))

        if distribution_priority == 'after_debt':
            remaining = max(ZERO, money(cash + cash_before_financing - payment - min_cash))
            dividend_paid = min(promised_dividend, remaining)
        dividend_gap = money(promised_dividend - dividend_paid)
        total_dividend_gap += dividend_gap
        cash = money(cash + cash_before_financing - payment - dividend_paid)
        if ending_debt == 0 and first_paid_off is None:
            first_paid_off = month
        rows.append({
            'month': month, 'sales': amount(sales), 'variable_cost': amount(variable),
            'receipts': amount(receipts), 'receivables_end': amount(new_receivable),
            'fcff_before_debt': amount(cash_before_financing),
            'interest': amount(interest), 'scheduled_payment': amount(due), 'paid': amount(payment),
            'shortfall': amount(gap), 'actual_payment': amount(payment),
            'coverage_ratio': (float(money((cash_before_financing - dividend_paid) / due)) if due else None),
            'investor_distribution': amount(dividend_paid),
            'dividend_shortfall': amount(dividend_gap), 'ending_cash': amount(cash),
            'cash_funding_gap': amount(max(ZERO, -cash)), 'ending_debt': amount(ending_debt),
            'end_cash': amount(cash), 'end_debt': amount(ending_debt),
            'by_creditor': [{'creditor': x['debt']['creditor'], 'interest': amount(x['interest']),
                             'minimum': amount(x['due']), 'paid': amount(x['payment']),
                             'ending_balance': amount(x['debt']['balance'])} for x in details]
        })
    return {
        'initial_debt': amount(initial_debt), 'scheduled_monthly_payment': amount(scheduled),
        'ending_debt': amount(sum((x['balance'] for x in debts), ZERO)),
        'ending_cash': amount(cash), 'total_interest': amount(total_interest),
        'total_interest_accrued': amount(total_interest),
        'months_with_payment_shortfall': sum(1 for x in rows if x['shortfall'] > 0),
        'total_payment_shortfall': amount(total_gap), 'total_dividend_shortfall': amount(total_dividend_gap),
        'paid_off_month': first_paid_off, 'target_met': first_paid_off is not None,
        'rows': rows,
        'assumptions': {
            'currency': 'IDR', 'debt_schedule': 'bunga efektif bulanan; angsuran sesuai parameter',
            'unpaid_interest': 'dalam simulasi bunga yang tidak dibayar ditambahkan ke saldo; kontrak dapat berbeda',
            'collection': 'piutang tertunda diasumsikan tertagih satu bulan kemudian',
            'dividends': f'distribusi investor dibayar {distribution_priority}; kekurangan dicatat, tidak dipaksakan',
            'cash': 'saldo negatif adalah gap pendanaan, bukan uang tunai tersedia',
            'restriction': 'simulasi, bukan ledger, nasihat kreditur, atau pencatatan akuntansi resmi'
        }
    }
