#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if command -v docker >/dev/null 2>&1; then
  if ! docker info >/dev/null 2>&1; then
    printf '%s\n' 'Docker terpasang tetapi Docker Engine belum aktif.' >&2
    exit 1
  fi
  docker compose up --build -d
  printf '%s\n' 'Debt Tracker: http://127.0.0.1:8090'
  docker compose ps
else
  if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' 'Python 3.12 atau Docker diperlukan.' >&2
    exit 1
  fi
  mkdir -p data
  printf '%s\n' 'Debt Tracker: http://127.0.0.1:8090 (Ctrl+C untuk berhenti)'
  exec python3 -m debt_tracker --host 127.0.0.1 --port 8090 --db data/debt.db
fi
