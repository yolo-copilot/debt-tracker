#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if ! command -v gh >/dev/null 2>&1; then
  printf '%s\n' 'GitHub CLI (gh) belum terpasang. Buat repository private yolo-copilot/debt-tracker secara manual, lalu jalankan git remote add origin + git push.' >&2
  exit 1
fi
if ! gh auth status >/dev/null 2>&1; then
  printf '%s\n' 'GitHub CLI belum login. Jalankan gh auth login.' >&2
  exit 1
fi
if [ ! -d .git ]; then
  git init
  git branch -M main
fi
if ! git config user.name >/dev/null 2>&1 || ! git config user.email >/dev/null 2>&1; then
  printf '%s\n' 'Git author belum diatur: jalankan git config user.name dan git config user.email.' >&2
  exit 1
fi
git add .
if ! git diff --cached --quiet; then git commit -m 'feat: standalone YOLO Debt Tracker'; fi
if ! gh repo view yolo-copilot/debt-tracker >/dev/null 2>&1; then
  gh repo create yolo-copilot/debt-tracker --private --description 'YOLO Debt Tracker independent cashflow and repayment planner'
fi
if ! git remote get-url origin >/dev/null 2>&1; then git remote add origin https://github.com/yolo-copilot/debt-tracker.git; fi
git push -u origin main
printf '%s\n' 'Paket terunggah ke https://github.com/yolo-copilot/debt-tracker'
