# YOLO Debt Tracker — Repository Mandiri

**Terpisah sepenuhnya dari ERP/MRP Central Kitchen**. Repository ini tidak memiliki dependensi, database, atau Docker service milik `yolo-builder`.

## Fitur
- Simulasi pelunasan satu hingga 30 kreditur: pokok, bunga, angsuran minimum, prioritas pembayaran, dan saldo.
- Arus kas hingga 30 lini usaha, biaya tetap, biaya variabel, pajak, belanja masalah, belanja modal, dan tambahan modal kerja.
- Distribusi investor dan cadangan kas minimum, serta penagihan piutang dengan asumsi tertagih bulan berikutnya.
- Simulasi target tenor, risiko gagal bayar, dan penyimpanan skenario di database lokal terpisah.

## Cara menjalankan (Docker)
```bash
docker compose up --build -d
curl -fsS http://127.0.0.1:8090/api/health
```
Buka **http://127.0.0.1:8090**. Volume terpisah `debt-data` untuk database simulasi utang.

## Tanpa Docker
```bash
python3 -m debt_tracker --host 127.0.0.1 --port 8090 --db data/debt.db
```
Atau jalankan `sh scripts/start-local.sh`. Python 3.12 direkomendasikan.

## Pengujian
```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q debt_tracker
```
CI pada `.github/workflows/checks.yml` menjalankan tes, Docker build dan smoke API.

## Status
- Aplikasi masih pilot localhost dan data simulasi. **Belum cocok diekspos publik.**
- Tidak ada sinkronisasi ke ERP/MRP ataupun pembacaan rekening bank.
- Perhitungan harus direkonsiliasi dengan perjanjian kreditur sebelum keputusan finansial.
- Pisahkan kredensial dan informasi keuangan aktual dari repositori Git.

Lihat `docs/DEBT_TRACKER.md` dan `docs/DEPLOYMENT.md`.
