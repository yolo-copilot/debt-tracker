# Pemisahan dan deployment

## Batas repository
`debt-tracker`: port 8090, volume Docker `debt-data`, database SQLite sendiri, image `debt-tracker:local`.
`yolo-builder`: port 8000, volume MRP tersendiri, tanpa import Python dari Debt Tracker.

## Prosedur migrasi aman
1. Backup data dari Docker volume `debt-data` jika sebelumnya sudah menginput skenario. Jangan menjalankan `docker compose down -v`.
2. Buat repository privat **baru** `yolo-copilot/debt-tracker` melalui GitHub.
3. Push paket ini ke repository baru, jalankan CI dan verifikasi `http://127.0.0.1:8090/api/health` pada mesin host.
4. Setelah data disalin dan diverifikasi, hapus layanan debt serta kode debt dari repository MRP.
5. Di MRP, `docker compose up --build -d` hanya menjalankan port 8000.

## Keamanan
Jangan mempublikasikan SQLite dan endpoint demo mentah ke internet. Untuk live hosting gunakan login per pengguna, otorisasi, HTTPS, pengendalian akses, backup, enkripsi data keuangan, audit aktivitas dan pemeriksaan keamanan.

## Validasi target migrasi
- Tidak ada import `debt_tracker` di MRP.
- CI MRP tidak menjalankan tes Debt Tracker.
- Docker Compose MRP tidak memiliki port 8090 dan `debt-data`.
- Docker Compose Debt Tracker tidak mempunyai port 8000 dan `mrp-data`.
- Semua tes Debt Tracker lulus pada repository baru.
