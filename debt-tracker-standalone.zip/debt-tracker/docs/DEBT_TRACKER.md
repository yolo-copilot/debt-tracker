# YOLO Debt Tracker — Panduan dan Audit v0.2

## Sumber rancangan

Rujukan pengguna: *Debt Tracker & Free Cash Flow Planner* (10 halaman), terutama register kreditur (hal. 3), kas per bisnis (hal. 4), alokasi FCF (hal. 5), kelayakan tenor (hal. 6), tracker dan rasio risiko (hal. 7–9). Nilai di PDF seperti Rp300 juta adalah **contoh**, bukan utang riil. Default antarmuka prototipe memakai Rp3 miliar dan 24 bulan sesuai target terpisah yang dinyatakan pengguna.

## Cakupan modul

1. Register hingga 30 kreditur, masing-masing pokok, bunga efektif tahunan, cicilan minimum atau anuitas otomatis, dan prioritas pembayaran.
2. Hingga 30 lini usaha: omzet, biaya variabel, dan pertumbuhan bulanan.
3. Biaya tetap, belanja masalah, pajak kas, capex, tambahan modal kerja, dan cadangan kas minimum.
4. Penerimaan kas (penjualan tunai/bulan berjalan dan piutang yang diasumsikan tertagih satu bulan berikutnya).
5. Distribusi investor dengan pilihan urutan sebelum atau sesudah pembayaran utang; **kewajiban hukum/kontrak tetap lebih tinggi dari parameter simulasi**.
6. Pembayaran minimum setiap kreditur terlebih dulu menurut prioritas; surplus ke kreditur prioritas; bunga yang tidak tertutup dikapitalisasi sebagai **asumsi**, bukan aturan kontrak universal.
7. Laporan bulanan sisa pokok, bunga, FCF, gap pembayaran, gap dividen, saldo kas, dan rasio penutupan kas indikatif.
8. Penyimpanan skenario lokal di SQLite. Belum ada pencatatan realisasi utang atau sinkronisasi ERP.

## Rumus inti

- FCF kas sebelum utang = penerimaan kas − biaya variabel − biaya tetap − pajak dibayar − belanja masalah − capex − tambahan modal kerja.
- Bunga per bulan = saldo masing-masing kreditur × (bunga efektif per tahun / 12).
- Angsuran anuitas = P × r / (1 − (1+r)^(-n)).
- Kas untuk distribusi/pembayaran = maks(0, kas awal bulan + FCF − kas minimum − prioritas kewajiban terdahulu).
- Gap minimum = maks(0, jumlah cicilan minimum bulan berjalan − pembayaran aktual).
- Coverage Ratio = (FCF sebelum utang − distribusi dibayar) / cicilan terjadwal; ukuran *indikatif*, bukan DSCR covenant resmi.

## Keterbatasan penting

- Simulasi bulanan, bukan jadwal tanggal harian dan bukan ledger bank.
- Piutang diasumsikan tertagih seluruhnya setelah satu bulan; gagal tagih dan invoice aging belum dimodelkan.
- Pokok, bunga, denda, dan jadwal angsuran harus direkonsiliasi terhadap kontrak kreditur.
- Belum memodelkan perubahan bunga, penundaan cicilan, denda, pajak badan lengkap, pinjaman baru, tambahan modal investor, dan konflik prioritas hukum.
- Kas negatif ditampilkan sebagai **gap kebutuhan pendanaan**, bukan saldo tunai yang benar-benar tersedia.
- Jika kontrak mengharuskan pembayaran dividen tertentu, kekurangan dicatat; **simulator tidak otomatis menjadikan seluruhnya utang investor**.
- Belum ada autentikasi pengguna produksi; localhost tidak boleh langsung dibuka ke jaringan publik.
- Belum terintegrasi dengan data MRP, ERPNext, atau rekening bank.

## Pengujian

Di folder repo:

```sh
python3 -m unittest discover -s tests -p 'test_debt_tracker.py' -v
python3 -m debt_tracker --host 127.0.0.1 --port 8090 --db data/debt.db
curl --fail http://127.0.0.1:8090/api/health
```

Docker Compose gabungan:

```sh
docker compose -f compose.yaml -f compose.debt.yaml up --build -d
```

Build Docker belum dapat diuji secara langsung pada lingkungan ChatGPT karena Docker Engine tidak tersedia; GitHub Actions CI sebaiknya menguji build keduanya sebelum digunakan produksi.
